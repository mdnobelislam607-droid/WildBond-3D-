(function () {
'use strict';
var T = THREE, $ = function (id) { return document.getElementById(id); };
var ls = function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } };
var save = function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} };
var S = { gfx: +ls('gfx', 0), sh: ls('sh', '0') === '1', mus: +ls('mus', 0.7), sfx: +ls('sfx', 0.7), level: +ls('level', 1) };
var page = 'menu', backPage = 'menu';

// ------------------------------------------------------------ renderer / scene
var cv = document.createElement('canvas'); document.body.insertBefore(cv, document.body.firstChild);
var R = new T.WebGLRenderer({ canvas: cv, antialias: false, powerPreference: 'high-performance' });
var scene = new T.Scene();
scene.background = new T.Color(0x9fc7f2);
scene.fog = new T.Fog(0x9fc7f2, 50, 140);
var cam = new T.PerspectiveCamera(60, 1, 0.2, 200);
scene.add(new T.HemisphereLight(0xdfe9ff, 0x6a7a40, 0.95));
var sun = new T.DirectionalLight(0xffeec8, 0.85);
sun.position.set(-30, 45, -25);
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -24; sun.shadow.camera.right = 24; sun.shadow.camera.top = 24; sun.shadow.camera.bottom = -24;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 120;
scene.add(sun); scene.add(sun.target);

var MATS = {}, GEOS = {};
function mat(c) { return MATS[c] || (MATS[c] = new T.MeshLambertMaterial({ color: c })); }
function boxGeo(w, h, d) { var k = w + '_' + h + '_' + d; return GEOS[k] || (GEOS[k] = new T.BoxGeometry(w, h, d)); }
function box(p, w, h, d, c, x, y, z, sh) {
  var m = new T.Mesh(boxGeo(w, h, d), mat(c)); m.position.set(x, y, z);
  m.castShadow = sh !== false; m.receiveShadow = sh !== false; p.add(m); return m;
}
function sph(p, c, x, y, z, sx, sy, sz) {
  var m = new T.Mesh(GEOS.sph || (GEOS.sph = new T.SphereGeometry(1, 10, 8)), mat(c));
  m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.castShadow = true; p.add(m); return m;
}
function piv(p, x, y, z) { var g = new T.Group(); g.position.set(x, y, z); p.add(g); return g; }

var seed = 7; function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
function rr(a, b) { return a + (b - a) * rnd(); }

// ------------------------------------------------------------ world
var OBS = [], grass;
function buildWorld() {
  var gnd = new T.Mesh(new T.PlaneGeometry(200, 200), mat(0x5c8c38));
  gnd.rotation.x = -Math.PI / 2; gnd.receiveShadow = true; scene.add(gnd);
  var path = new T.Mesh(new T.PlaneGeometry(3, 60), mat(0x806a45));
  path.rotation.x = -Math.PI / 2; path.position.set(0, 0.02, 10); path.receiveShadow = true; scene.add(path);

  for (var i = 0; i < 10; i++) {
    var a = i * Math.PI * 2 / 10;
    var h = new T.Mesh(GEOS.sph || (GEOS.sph = new T.SphereGeometry(1, 10, 8)), mat(0x6b8580));
    h.position.set(Math.cos(a) * 95, 0, Math.sin(a) * 95);
    h.scale.set(35, 14 + rnd() * 14, 28); scene.add(h);
  }
  // house
  var hs = new T.Group(); hs.position.set(0, 0, 32); scene.add(hs);
  box(hs, 7, 3.5, 5, 0x9a8061, 0, 1.75, 0);
  var r1 = box(hs, 4.3, 0.25, 5.8, 0x59382a, -1.8, 4.3, 0); r1.rotation.z = 0.52;
  var r2 = box(hs, 4.3, 0.25, 5.8, 0x59382a, 1.8, 4.3, 0); r2.rotation.z = -0.52;
  box(hs, 1.2, 2, 0.1, 0x6b4c2d, 0, 1, -2.55);
  box(hs, 1, 1, 0.1, 0x9fd0e8, 2.2, 1.8, -2.55);
  OBS.push({ x: 0, z: 32, r: 5 });
  // fence (gate gap in the middle)
  var wood = 0x6b4c2d;
  for (var x = -20; x <= 20; x += 1.2) {
    if (Math.abs(x) < 3.5) continue;
    box(scene, 0.12, 1.2, 0.12, wood, x, 0.6, 14);
    OBS.push({ x: x, z: 14, r: 0.35 });
  }
  [-11.75, 11.75].forEach(function (cx) {
    box(scene, 16.5, 0.08, 0.08, wood, cx, 0.95, 14);
    box(scene, 16.5, 0.08, 0.08, wood, cx, 0.5, 14);
  });
  // pond
  var pond = new T.Mesh(new T.CylinderGeometry(6, 6, 0.05, 24), mat(0x3a73bd));
  pond.position.set(-25, 0.03, -20); scene.add(pond);
  OBS.push({ x: -25, z: -20, r: 6.2 });
  // trees (instanced)
  var pos = [];
  for (var t = 0; t < 70 && pos.length < 45; t++) {
    var tx = rr(-44, 44), tz = rr(-44, 44);
    if (tx * tx + (tz + 6) * (tz + 6) < 64 || tx * tx + (tz - 32) * (tz - 32) < 100 || Math.abs(tz - 14) < 2.5 ||
        (tx + 25) * (tx + 25) + (tz + 20) * (tz + 20) < 64 || (tx - 6) * (tx - 6) + (tz - 8) * (tz - 8) < 16) continue;
    pos.push([tx, tz]); OBS.push({ x: tx, z: tz, r: 0.7 });
  }
  var trunks = new T.InstancedMesh(new T.CylinderGeometry(0.2, 0.28, 3, 6), mat(0x6b4c2d), pos.length);
  var crowns = new T.InstancedMesh(new T.SphereGeometry(1, 8, 6), mat(0x347a2c), pos.length);
  var d = new T.Object3D();
  pos.forEach(function (p, i) {
    d.position.set(p[0], 1.5, p[1]); d.scale.set(1, 1, 1); d.rotation.set(0, 0, 0); d.updateMatrix(); trunks.setMatrixAt(i, d.matrix);
    var s = rr(1.4, 2); d.position.set(p[0], 3.8, p[1]); d.scale.set(s, s, s); d.updateMatrix(); crowns.setMatrixAt(i, d.matrix);
  });
  trunks.castShadow = crowns.castShadow = true; scene.add(trunks); scene.add(crowns);
  // grass tufts (instanced)
  grass = new T.InstancedMesh(boxGeo(0.12, 0.55, 0.12), mat(0x4da83a), 320);
  for (var g = 0; g < 320; g++) {
    d.position.set(rr(-45, 45), 0.25, rr(-45, 45)); d.scale.set(1, 1, 1);
    d.rotation.set(rr(-0.25, 0.25), rr(0, 6.28), rr(-0.25, 0.25)); d.updateMatrix(); grass.setMatrixAt(g, d.matrix);
  }
  scene.add(grass);
}

// ------------------------------------------------------------ characters
var pl = new T.Group(), plVis = new T.Group(), plLegL, plLegR, plArmL, plArmR;
function buildPlayer() {
  scene.add(pl); pl.add(plVis);
  var skin = 0xe6b894, shirt = 0x545c70, jeans = 0x334d80, pack = 0x333329;
  box(plVis, 0.5, 0.6, 0.28, shirt, 0, 1.25, 0);
  sph(plVis, skin, 0, 1.78, 0, 0.15, 0.16, 0.15);
  sph(plVis, 0x1a1411, 0, 1.86, -0.03, 0.16, 0.11, 0.16);
  box(plVis, 0.4, 0.5, 0.22, pack, 0, 1.3, -0.25);
  plLegL = piv(plVis, -0.13, 0.9, 0); box(plLegL, 0.2, 0.9, 0.22, jeans, 0, -0.45, 0);
  plLegR = piv(plVis, 0.13, 0.9, 0); box(plLegR, 0.2, 0.9, 0.22, jeans, 0, -0.45, 0);
  plArmL = piv(plVis, -0.33, 1.5, 0); box(plArmL, 0.14, 0.6, 0.16, shirt, 0, -0.3, 0);
  plArmR = piv(plVis, 0.33, 1.5, 0); box(plArmR, 0.14, 0.6, 0.16, shirt, 0, -0.3, 0);
}
var dog = new T.Group(), dHead, dTail, dEarL, dEarR, dLegs = [];
function buildDog() {
  scene.add(dog);
  var gold = 0xd19447, dark = 0x8c5c29;
  box(dog, 0.4, 0.4, 0.9, gold, 0, 0.65, 0);
  dHead = piv(dog, 0, 0.9, 0.55);
  box(dHead, 0.3, 0.3, 0.32, gold, 0, 0.05, 0.12);
  box(dHead, 0.16, 0.14, 0.2, dark, 0, -0.02, 0.35);
  dEarL = piv(dHead, -0.13, 0.2, 0.05); box(dEarL, 0.07, 0.2, 0.14, dark, 0, -0.05, 0);
  dEarR = piv(dHead, 0.13, 0.2, 0.05); box(dEarR, 0.07, 0.2, 0.14, dark, 0, -0.05, 0);
  dTail = piv(dog, 0, 0.8, -0.45); box(dTail, 0.08, 0.35, 0.08, gold, 0, 0.15, 0);
  var lx = [-0.15, 0.15, -0.15, 0.15], lz = [0.32, 0.32, -0.32, -0.32];
  for (var i = 0; i < 4; i++) { var l = piv(dog, lx[i], 0.45, lz[i]); box(l, 0.1, 0.45, 0.1, gold, 0, -0.22, 0); dLegs.push(l); }
}

// ------------------------------------------------------------ audio (generated, no files)
var AC, mg, sg;
function initAudio() {
  if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    mg = AC.createGain(); mg.gain.value = S.mus * 0.25; mg.connect(AC.destination);
    [220, 275, 330].forEach(function (f) {
      var o = AC.createOscillator(); o.type = 'sine'; o.frequency.value = f;
      var g = AC.createGain(); g.gain.value = 0.3; o.connect(g); g.connect(mg); o.start();
    });
    sg = AC.createGain(); sg.gain.value = S.sfx; sg.connect(AC.destination);
  } catch (e) { AC = null; }
}
function woof() {
  if (!AC) return;
  var t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
  o.type = 'sawtooth'; o.frequency.setValueAtTime(420, t); o.frequency.exponentialRampToValueAtTime(150, t + 0.25);
  g.gain.setValueAtTime(0.4, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
  o.connect(g); g.connect(sg); o.start(t); o.stop(t + 0.3);
}
document.addEventListener('pointerdown', initAudio);

// ------------------------------------------------------------ settings
function applyGfx() {
  var dpr = Math.min(window.devicePixelRatio || 1, 2), k = [0.6, 0.8, 1][S.gfx];
  R.setPixelRatio(dpr * k); R.setSize(innerWidth, innerHeight, false);
  cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix();
  grass.visible = S.gfx > 0;
  R.shadowMap.enabled = S.sh; sun.castShadow = S.sh;
  scene.fog.far = S.gfx === 0 ? 110 : 140;
  scene.traverse(function (o) { if (o.material) o.material.needsUpdate = true; });
  var q = document.querySelectorAll('.gq');
  for (var i = 0; i < q.length; i++) q[i].classList.toggle('on2', +q[i].getAttribute('data-q') === S.gfx);
  $('gnote').style.visibility = S.gfx === 0 ? 'visible' : 'hidden';
  $('shBtn').textContent = S.sh ? 'ON' : 'OFF'; $('shBtn').classList.toggle('on2', S.sh);
  save('gfx', S.gfx); save('sh', S.sh ? 1 : 0);
}
window.addEventListener('resize', function () { applyGfx(); });

// ------------------------------------------------------------ game state
var plYaw = 0, camYaw = 0, camPitch = 0.32, anim = 0, spd = 0, bond = 0, stam = 100, run = false;
var interactT = 0, gain = 12, levelT = 0, msgT = 0, menuT = 0, stars = 3;
var dYaw = 0, dSpeed = 0, dPhase = 0, dWait = 0, dTarget = new T.Vector3(), dHappy = 0.4;
var joy = { id: null, sx: 0, sy: 0, x: 0, y: 0 }, lk = { id: null, x: 0, y: 0, dx: 0, dy: 0 };
var keys = {};

function dA(a, b) { var d = (b - a) % (2 * Math.PI); if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI; return d; }
function resolve(p, r) {
  for (var i = 0; i < OBS.length; i++) {
    var o = OBS[i], dx = p.x - o.x, dz = p.z - o.z, m = Math.sqrt(dx * dx + dz * dz), mn = o.r + r;
    if (m < mn && m > 0.001) { p.x = o.x + dx / m * mn; p.z = o.z + dz / m * mn; }
  }
  p.x = Math.max(-46, Math.min(46, p.x)); p.z = Math.max(-46, Math.min(46, p.z)); return p;
}
function msg(s) { $('msg').textContent = s; msgT = 1.6; }

function resetLevel() {
  bond = 0; stam = 100; run = false; levelT = 0; interactT = 0; joy.id = lk.id = null;
  gain = Math.max(4, 14 - 2 * S.level);
  pl.position.set(0, 0, -6); plYaw = 0; camYaw = 0; camPitch = 0.32; plVis.scale.set(1, 1, 1);
  dog.position.set(Math.min(30, Math.max(6, 6 + S.level * 3)), 0, 10);
  dYaw = 3.5; dSpeed = 0; dWait = 0; dTarget.copy(dog.position);
  cam.position.set(0, 3, -12);
}
function show(p) {
  page = p;
  ['menu', 'settings', 'sound', 'pause', 'done'].forEach(function (id) { $(id).classList.toggle('on', id === p); });
  $('hud').classList.toggle('hide', !(p === 'play' || p === 'pause'));
}
function startGame() { resetLevel(); show('play'); }
function complete() {
  stars = levelT < 90 ? 3 : levelT < 180 ? 2 : 1;
  S.level++; save('level', S.level);
  $('stars').innerHTML = [0, 1, 2].map(function (i) { return i < stars ? '<b>★</b>' : '★'; }).join('');
  show('done');
}
function doPet() {
  if (page !== 'play' || interactT > 0) return;
  if (pl.position.distanceTo(dog.position) > 3) { msg('Get closer to the dog'); return; }
  interactT = 2.2; bond = Math.min(100, bond + gain); msg('Good boy!  +' + Math.round(gain)); woof();
}

// ------------------------------------------------------------ per-frame logic
function playerPose(sp, dt, crouch) {
  anim += sp * dt * 3; var k = Math.min(1, sp / 2.3), s = Math.sin(anim) * 0.6 * k;
  plLegL.rotation.x = s; plLegR.rotation.x = -s;
  plArmL.rotation.x = crouch ? -1.0 : -s; plArmR.rotation.x = crouch ? -1.2 : s;
  plVis.scale.y += ((crouch ? 0.72 : 1) - plVis.scale.y) * Math.min(1, 10 * dt);
  pl.rotation.y = plYaw;
}

function animateDog(dt, happy, d) {
  var k = Math.min(1, dSpeed / 2); dPhase += dSpeed * dt * 4.5;
  for (var i = 0; i < 4; i++) dLegs[i].rotation.x = Math.sin(dPhase + ((i === 0 || i === 3) ? 0 : Math.PI)) * 0.55 * k;
  dTail.rotation.x = -1.8 + 1.2 * happy;
  dTail.rotation.z = Math.sin(performance.now() / 1000 * (6 + 9 * happy)) * (0.35 + 0.45 * happy) * happy;
  var wx = pl.position.x - dog.position.x, wz = pl.position.z - dog.position.z, c = Math.cos(dYaw), s = Math.sin(dYaw);
  var lx = wx * c - wz * s, lz = wx * s + wz * c;
  var ang = Math.max(-0.9, Math.min(0.9, Math.atan2(lx, lz)));
  dHead.rotation.y += ((d < 9 ? ang : 0) - dHead.rotation.y) * Math.min(1, 6 * dt);
  var ear = 0.2 + (1 - happy) * 0.7; dEarL.rotation.z = -ear; dEarR.rotation.z = ear;
  dog.rotation.y = dYaw;
}

function dogUpdate(dt, petting) {
  var dp = dog.position, tx = pl.position.x - dp.x, tz = pl.position.z - dp.z, d = Math.sqrt(tx * tx + tz * tz);
  var dx = tx, dz = tz, want = 0, happy = 0.4;
  if (petting) happy = 1;
  else if (spd > 3.5 && d < 5 && d > 1.2) { dx = -tx; dz = -tz; want = 2.6; happy = 0.1; }  // runs away when scared
  else if (d < 2.2) happy = 0.8;
  else if (d < 16) { want = d > 8 ? 3.8 : 1.8; happy = 0.7; }                                 // follows the player
  else {
    dWait -= dt;
    if (dWait <= 0 || dTarget.distanceToSquared(dp) < 1) { dTarget.set(rr(-35, 35), 0, rr(-35, 35)); dWait = rr(4, 9); }
    dx = dTarget.x - dp.x; dz = dTarget.z - dp.z; want = 1.2;                                  // wanders
  }
  if (dx * dx + dz * dz > 0.01) {
    var ty = Math.atan2(dx, dz), df = dA(dYaw, ty);
    dYaw += Math.max(-3.5 * dt, Math.min(3.5 * dt, df));
    if (Math.abs(dA(dYaw, ty)) > 0.9) want *= 0.2;
  }
  dSpeed += (want - dSpeed) * Math.min(1, 6 * dt);
  dp.x += Math.sin(dYaw) * dSpeed * dt; dp.z += Math.cos(dYaw) * dSpeed * dt; resolve(dp, 0.35);
  var sx = dp.x - pl.position.x, sz = dp.z - pl.position.z, sm = Math.sqrt(sx * sx + sz * sz);
  if (sm < 0.9 && sm > 0.0001) { dp.x = pl.position.x + sx / sm * 0.9; dp.z = pl.position.z + sz / sm * 0.9; }
  dHappy = happy; animateDog(dt, happy, d);
}

function playUpdate(dt) {
  levelT += dt;
  camYaw -= lk.dx * 0.006; camPitch = Math.max(0.1, Math.min(1.0, camPitch + lk.dy * 0.004)); lk.dx = lk.dy = 0;
  var mx = joy.x + ((keys.d || keys.ArrowRight) ? 1 : 0) - ((keys.a || keys.ArrowLeft) ? 1 : 0);
  var my = -joy.y + ((keys.w || keys.ArrowUp) ? 1 : 0) - ((keys.s || keys.ArrowDown) ? 1 : 0);
  var mm = Math.sqrt(mx * mx + my * my); if (mm > 1) { mx /= mm; my /= mm; mm = 1; }
  var petting = interactT > 0; spd = 0;
  if (petting) {
    interactT -= dt; mm = 0;
    plYaw += dA(plYaw, Math.atan2(dog.position.x - pl.position.x, dog.position.z - pl.position.z)) * Math.min(1, 8 * dt);
  }
  var running = false;
  if (mm > 0.1) {
    running = (run || keys.Shift) && stam > 2;
    spd = (running ? 4.6 : 2.3) * mm;
    var fx = Math.sin(camYaw), fz = Math.cos(camYaw), rx = -Math.cos(camYaw), rz = Math.sin(camYaw);
    var dx = fx * my + rx * mx, dz = fz * my + rz * mx, dl = Math.sqrt(dx * dx + dz * dz);
    dx /= dl; dz /= dl;
    plYaw += dA(plYaw, Math.atan2(dx, dz)) * Math.min(1, 12 * dt);
    pl.position.x += dx * spd * dt; pl.position.z += dz * spd * dt; resolve(pl.position, 0.4);
  }
  stam = running ? stam - 20 * dt : Math.min(100, stam + 12 * dt);
  if (stam <= 2) run = false;
  playerPose(spd, dt, petting);
  dogUpdate(dt, petting);
  // camera
  var ty = pl.position.y + 1.5, cp = Math.cos(camPitch), sp = Math.sin(camPitch);
  var wx = pl.position.x - Math.sin(camYaw) * cp * 5.2, wy = Math.max(0.5, ty + sp * 5.2), wz = pl.position.z - Math.cos(camYaw) * cp * 5.2;
  var f = 1 - Math.exp(-14 * dt);
  cam.position.x += (wx - cam.position.x) * f; cam.position.y += (wy - cam.position.y) * f; cam.position.z += (wz - cam.position.z) * f;
  cam.lookAt(pl.position.x, ty, pl.position.z);
  // HUD
  $('fBond').style.width = bond + '%'; $('fStam').style.width = stam + '%'; $('lv').textContent = 'Lv ' + S.level;
  var near = pl.position.distanceTo(dog.position) < 3;
  $('bpet').classList.toggle('act', near); $('tip').classList.toggle('hide', !(near && interactT <= 0));
  $('brun').classList.toggle('act', run);
  if (bond >= 100 && !petting) complete();
}

function menuUpdate(dt) {
  menuT += dt;
  pl.position.set(0, 0, 0); plYaw = Math.PI / 2; playerPose(0, dt, true);
  dog.position.set(1.3, 0, 0.1); dYaw = -Math.PI / 2; dSpeed = 0; animateDog(dt, 1, 1.3);
  var a = Math.sin(menuT * 0.25) * 0.35;
  cam.position.set(0.65 + Math.sin(a) * 3.6, 1.45, -Math.cos(a) * 3.6);
  cam.lookAt(0.65, 0.85, 0);
}

// ------------------------------------------------------------ input
function joyVisual() {
  var cx = joy.id !== null ? joy.sx : 110, cy = joy.id !== null ? joy.sy : innerHeight - 110;
  var jb = $('jb'), jk = $('jk');
  jb.style.left = (cx - 60) + 'px'; jb.style.top = (cy - 60) + 'px';
  jk.style.left = (cx + joy.x * 60 - 26) + 'px'; jk.style.top = (cy + joy.y * 60 - 26) + 'px';
}
function isBtn(t) { return t && t.closest && t.closest('.btn'); }
document.addEventListener('touchstart', function (e) {
  if (page !== 'play') return;
  for (var i = 0; i < e.changedTouches.length; i++) {
    var t = e.changedTouches[i]; if (isBtn(t.target)) continue;
    if (t.clientX < innerWidth * 0.45) { if (joy.id === null) { joy.id = t.identifier; joy.sx = t.clientX; joy.sy = t.clientY; joy.x = joy.y = 0; } }
    else if (lk.id === null) { lk.id = t.identifier; lk.x = t.clientX; lk.y = t.clientY; }
  }
}, { passive: true });
document.addEventListener('touchmove', function (e) {
  if (page !== 'play') return;
  for (var i = 0; i < e.changedTouches.length; i++) {
    var t = e.changedTouches[i];
    if (t.identifier === joy.id) {
      var x = (t.clientX - joy.sx) / 60, y = (t.clientY - joy.sy) / 60, m = Math.sqrt(x * x + y * y);
      if (m > 1) { x /= m; y /= m; } joy.x = x; joy.y = y;
    } else if (t.identifier === lk.id) { lk.dx += t.clientX - lk.x; lk.dy += t.clientY - lk.y; lk.x = t.clientX; lk.y = t.clientY; }
  }
}, { passive: true });
function tend(e) {
  for (var i = 0; i < e.changedTouches.length; i++) {
    var id = e.changedTouches[i].identifier;
    if (id === joy.id) { joy.id = null; joy.x = joy.y = 0; }
    if (id === lk.id) lk.id = null;
  }
}
document.addEventListener('touchend', tend); document.addEventListener('touchcancel', tend);
// desktop testing: WASD, E = pet, Shift = run, Esc = pause
document.addEventListener('keydown', function (e) {
  keys[e.key] = true; if (e.key.length === 1) keys[e.key.toLowerCase()] = true;
  if (e.key === 'e' || e.key === 'E') doPet();
  if (e.key === 'Escape') window.onBack();
});
document.addEventListener('keyup', function (e) { keys[e.key] = false; if (e.key.length === 1) keys[e.key.toLowerCase()] = false; });

function tap(id, fn) { $(id).addEventListener('pointerdown', function (e) { e.stopPropagation(); fn(); }); }
tap('bpet', doPet);
tap('brun', function () { run = !run; });
tap('bpause', function () { show('pause'); });

function on(id, fn) { $(id).addEventListener('click', fn); }
on('mPlay', startGame);
on('mSet', function () { backPage = 'menu'; show('settings'); });
on('mSnd', function () { backPage = 'menu'; show('sound'); });
on('mQuit', function () { if (window.Android) Android.quit(); });
on('setBack', function () { show(backPage); });
on('setSnd', function () { show('sound'); });
on('sndBack', function () { show(backPage); });
on('pRes', function () { show('play'); });
on('pRst', startGame);
on('pSet', function () { backPage = 'pause'; show('settings'); });
on('pExit', function () { show('menu'); });
on('dNext', startGame);
on('dMenu', function () { show('menu'); });
on('shBtn', function () { S.sh = !S.sh; applyGfx(); });
Array.prototype.forEach.call(document.querySelectorAll('.gq'), function (b) {
  b.addEventListener('click', function () {
    S.gfx = +b.getAttribute('data-q'); S.sh = S.gfx === 2; applyGfx();
  });
});
function slider(id, vid, key, apply) {
  var el = $(id); el.value = Math.round(S[key] * 100); $(vid).textContent = el.value + '%';
  el.addEventListener('input', function () { S[key] = el.value / 100; $(vid).textContent = el.value + '%'; save(key, S[key]); apply(); });
}
slider('sMus', 'vMus', 'mus', function () { if (mg) mg.gain.value = S.mus * 0.25; });
slider('sSfx', 'vSfx', 'sfx', function () { if (sg) sg.gain.value = S.sfx; });

window.onBack = function () {
  if (page === 'play') show('pause');
  else if (page === 'pause') show('play');
  else if (page === 'settings' || page === 'sound') show(backPage);
  else if (page === 'done') show('menu');
  else if (window.Android) Android.quit();
};
window.onHide = function () { if (page === 'play') show('pause'); };
document.addEventListener('visibilitychange', function () { if (document.hidden) window.onHide(); });

// ------------------------------------------------------------ main loop
buildWorld(); buildPlayer(); buildDog(); applyGfx(); resetLevel(); show('menu');
var last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  var dt = Math.min((now - last) / 1000, 0.05); last = now;
  if (msgT > 0) { msgT -= dt; if (msgT <= 0) $('msg').textContent = ''; }
  if (page === 'menu' || ((page === 'settings' || page === 'sound') && backPage === 'menu')) menuUpdate(dt);
  else if (page === 'play') playUpdate(dt);
  else if (page === 'done') { /* keep last frame */ }
  sun.position.set(pl.position.x - 30, 45, pl.position.z - 25); sun.target.position.copy(pl.position);
  joyVisual();
  R.render(scene, cam);
}
requestAnimationFrame(loop);
})();
