# Animal Friend – অফলাইন 3D অ্যানিমাল গেম (Unity, Android)

## APK বানানোর স্টেপ (GitHub Actions)

1. GitHub-এ নতুন repo খুলে এই পুরো ফোল্ডার push করো (branch: `main`)।
2. **Unity License (একবারই)**: Unity Personal ফ্রি লাইসেন্স দরকার।
   - Repo → Actions → "Acquire Unity activation file" workflow ব্যবহার করো
     (https://game.ci/docs/github/activation) এবং `.alf` ফাইল নামিয়ে https://license.unity3d.com/manual এ আপলোড করে `.ulf` নাও।
3. Repo → Settings → Secrets and variables → Actions এ ৩টি secret দাও:
   - `UNITY_LICENSE` = `.ulf` ফাইলের পুরো লেখা
   - `UNITY_EMAIL` = তোমার Unity অ্যাকাউন্ট ইমেইল
   - `UNITY_PASSWORD` = Unity পাসওয়ার্ড
4. Actions ট্যাবে **Build Android APK** → Run workflow (বা push করলেই চলবে)।
5. শেষ হলে run পেজের Artifacts থেকে `AnimalFriend-APK` নামিয়ে ফোনে install করো (Unknown sources অন করে)।

## কন্ট্রোল
- বাম দিকে ড্র্যাগ = হাঁটা, ডান দিকে সোয়াইপ = ক্যামেরা ঘোরানো
- **PET** বাটন = কুকুরের কাছে গেলে সক্রিয় (Bond বাড়ে, ১০০ হলে লেভেল শেষ)
- **RUN** = দৌড় (কুকুরের কাছে দৌড়ালে সে ভয় পেয়ে সরে যায়)
- PC টেস্ট: WASD, E = interact, মাউসের ডান বাটন = ক্যামেরা

## সীমাবদ্ধতা (সৎ রিপোর্ট)
- এখানে Unity ইনস্টল নেই, তাই **গেমটি বিল্ড বা টেস্ট করা হয়নি**। প্রথম Actions রানে কম্পাইল এরর এলে লগ পাঠাও, ঠিক করে দেব।
- কোনো ভিডিও পাইনি, শুধু একটি ছবি (গেমের UI/স্ক্রিনশট কোলাজ) পেয়েছি। তাই ছবির মতো দৃশ্য বানিয়েছি: ছেলে + ব্যাকপ্যাক, গোল্ডেন কুকুর, গ্রামের বাড়ি, বেড়া, পুকুর।
- মডেলগুলো কোড-জেনারেটেড লো-পলি (বক্স/স্ফিয়ার), ছবির মতো রিয়েলিস্টিক নয়। রিয়েলিস্টিক করতে লাইসেন্সড মডেল/অ্যানিমেশন (Asset Store/Mixamo) `Assets/` এ যোগ করতে হবে।
- সেভ: লেভেল ও সেটিংস PlayerPrefs-এ লোকালি সেভ হয়। পুরোপুরি অফলাইন, কোনো নেটওয়ার্ক কোড নেই।
- 2GB RAM-এর জন্য Low গ্রাফিক্স ডিফল্ট (ছোট রেজোলিউশন, শ্যাডো/AA বন্ধ, ৩০ FPS)।
