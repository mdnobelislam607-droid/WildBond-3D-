using System.Collections.Generic;
using UnityEngine;

// Animal Friend - পুরো গেম কোড দিয়ে তৈরি হয় (কোনো বাইরের অ্যাসেট লাগে না, 100% অফলাইন)।
public class AnimalFriendGame : MonoBehaviour
{
    enum Page { Menu, Play, Pause, Settings, Sound, Complete }
    Page page = Page.Menu, back = Page.Menu;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot() { new GameObject("AnimalFriend").AddComponent<AnimalFriendGame>(); }

    // world
    Camera cam; Light sun; GameObject grassRoot; Shader baseShader;
    readonly List<Vector3> obs = new List<Vector3>(); // x, z, radius
    readonly Dictionary<int, Material> mats = new Dictionary<int, Material>();
    // player
    Transform pl, plVis, plLegL, plLegR, plArmL, plArmR;
    float plYaw, camYaw, camPitch = 18f, plSpeed, anim;
    // dog
    Transform dog, dHead, dTail, dEarL, dEarR; Transform[] dLegs = new Transform[4];
    Vector3 dTarget; float dWait, dSpeed, dYaw, dPhase;
    // state
    float bond, stamina = 100f, interactTimer, gain = 12f, levelTime, msgTimer, menuT;
    int level = 1, stars = 3; bool run; string msg = "";
    // input
    int joyId = -1, lookId = -1; Vector2 joyStart, joyVec;
    Rect rInteract, rRun, rPause;
    // settings
    int gfx, resI; bool shadows, aa; float volMusic = .7f, volSfx = .7f;
    int nativeW, nativeH;
    AudioSource musicSrc, sfxSrc; AudioClip woof;
    GUIStyle label, btn; Texture2D circ; float S = 1f, vw = 1280f, vh = 720f;

    // ---------------------------------------------------------------- setup
    void Awake()
    {
        Application.targetFrameRate = 30;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        nativeW = Screen.width; nativeH = Screen.height;
        gfx = PlayerPrefs.GetInt("gfx", 0); resI = PlayerPrefs.GetInt("res", 1);
        shadows = PlayerPrefs.GetInt("sh", 0) == 1; aa = PlayerPrefs.GetInt("aa", 0) == 1;
        volMusic = PlayerPrefs.GetFloat("mus", .7f); volSfx = PlayerPrefs.GetFloat("sfx", .7f);
        level = PlayerPrefs.GetInt("level", 1);
        BuildWorld(); BuildAudio(); ApplyGfx(); ResetLevel(); EnterMenu();
    }

    Material Mat(Color c)
    {
        Color32 k = c; int key = (k.r << 16) | (k.g << 8) | k.b;
        Material m;
        if (!mats.TryGetValue(key, out m)) { m = new Material(baseShader); m.color = c; mats[key] = m; }
        return m;
    }

    Transform Prim(PrimitiveType t, Transform parent, Vector3 pos, Vector3 sc, Color c, bool shadow = true)
    {
        var g = GameObject.CreatePrimitive(t);
        Destroy(g.GetComponent<Collider>());
        var tr = g.transform; tr.SetParent(parent, false); tr.localPosition = pos; tr.localScale = sc;
        var r = g.GetComponent<Renderer>(); r.sharedMaterial = Mat(c);
        if (!shadow) { r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; r.receiveShadows = false; }
        return tr;
    }

    Transform Pivot(Transform p, Vector3 pos)
    {
        var g = new GameObject("pivot").transform; g.SetParent(p, false); g.localPosition = pos; return g;
    }

    void BuildWorld()
    {
        var tmp = GameObject.CreatePrimitive(PrimitiveType.Cube);
        baseShader = Shader.Find("Legacy Shaders/Diffuse");
        if (baseShader == null) baseShader = tmp.GetComponent<Renderer>().sharedMaterial.shader;
        Destroy(tmp);

        var cg = new GameObject("Cam"); cg.tag = "MainCamera";
        cam = cg.AddComponent<Camera>(); cg.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.62f, .78f, .95f);
        cam.nearClipPlane = .2f;
        RenderSettings.fog = true; RenderSettings.fogColor = cam.backgroundColor;
        RenderSettings.fogMode = FogMode.Linear; RenderSettings.fogStartDistance = 50; RenderSettings.fogEndDistance = 150;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(.55f, .55f, .5f);

        var lg = new GameObject("Sun"); sun = lg.AddComponent<Light>();
        sun.type = LightType.Directional; sun.intensity = 1.1f; sun.color = new Color(1f, .93f, .78f);
        lg.transform.rotation = Quaternion.Euler(45, -35, 0);

        Color wood = new Color(.42f, .3f, .18f);
        Prim(PrimitiveType.Cube, null, new Vector3(0, -.5f, 0), new Vector3(200, 1, 200), new Color(.36f, .55f, .22f), false);
        Prim(PrimitiveType.Cube, null, new Vector3(0, .02f, 10), new Vector3(3, .05f, 60), new Color(.5f, .4f, .27f), false);
        // hills
        Random.InitState(7);
        for (int i = 0; i < 10; i++)
        {
            float a = i * Mathf.PI * 2f / 10f;
            Prim(PrimitiveType.Sphere, null, new Vector3(Mathf.Cos(a) * 95, 0, Mathf.Sin(a) * 95),
                new Vector3(70, 25 + Random.Range(0, 20), 50), new Color(.42f, .52f, .5f), false);
        }
        // house
        var house = new GameObject("House").transform; house.position = new Vector3(0, 0, 32);
        Prim(PrimitiveType.Cube, house, new Vector3(0, 1.75f, 0), new Vector3(7, 3.5f, 5), new Color(.6f, .5f, .38f));
        var r1 = Prim(PrimitiveType.Cube, house, new Vector3(-1.8f, 4.3f, 0), new Vector3(4.3f, .25f, 5.8f), new Color(.35f, .22f, .16f));
        r1.localRotation = Quaternion.Euler(0, 0, 30);
        var r2 = Prim(PrimitiveType.Cube, house, new Vector3(1.8f, 4.3f, 0), new Vector3(4.3f, .25f, 5.8f), new Color(.35f, .22f, .16f));
        r2.localRotation = Quaternion.Euler(0, 0, -30);
        Prim(PrimitiveType.Cube, house, new Vector3(0, 1f, -2.55f), new Vector3(1.2f, 2f, .1f), wood);
        obs.Add(new Vector3(0, 32, 5f));
        // fence with gate gap
        for (float x = -20; x <= 20; x += 1.2f)
        {
            if (Mathf.Abs(x) < 3.5f) continue;
            Prim(PrimitiveType.Cube, null, new Vector3(x, .6f, 14), new Vector3(.12f, 1.2f, .12f), wood);
            obs.Add(new Vector3(x, 14, .35f));
        }
        foreach (float cx in new[] { -11.75f, 11.75f })
        {
            Prim(PrimitiveType.Cube, null, new Vector3(cx, .95f, 14), new Vector3(16.5f, .08f, .08f), wood);
            Prim(PrimitiveType.Cube, null, new Vector3(cx, .5f, 14), new Vector3(16.5f, .08f, .08f), wood);
        }
        // pond
        Prim(PrimitiveType.Cylinder, null, new Vector3(-25, .03f, -20), new Vector3(12, .02f, 12), new Color(.2f, .45f, .75f), false);
        obs.Add(new Vector3(-25, -20, 6.2f));
        // trees
        for (int i = 0; i < 45; i++)
        {
            float x = Random.Range(-44f, 44f), z = Random.Range(-44f, 44f);
            if (x * x + (z + 6) * (z + 6) < 64 || x * x + (z - 32) * (z - 32) < 100 || Mathf.Abs(z - 14) < 2.5f
                || (x + 25) * (x + 25) + (z + 20) * (z + 20) < 64 || (x - 6) * (x - 6) + (z - 8) * (z - 8) < 16) continue;
            Prim(PrimitiveType.Cylinder, null, new Vector3(x, 1.5f, z), new Vector3(.4f, 1.5f, .4f), wood);
            float s = Random.Range(2.6f, 3.8f);
            Prim(PrimitiveType.Sphere, null, new Vector3(x, 3.8f, z), new Vector3(s, s, s), new Color(.2f, .45f + Random.Range(0, .15f), .18f));
            obs.Add(new Vector3(x, z, .7f));
        }
        // grass tufts
        grassRoot = new GameObject("Grass");
        for (int i = 0; i < 120; i++)
        {
            var g = Prim(PrimitiveType.Cube, grassRoot.transform,
                new Vector3(Random.Range(-45f, 45f), .25f, Random.Range(-45f, 45f)),
                new Vector3(.12f, .55f, .12f), i % 2 == 0 ? new Color(.3f, .65f, .2f) : new Color(.4f, .72f, .25f), false);
            g.localRotation = Quaternion.Euler(Random.Range(-15, 15), Random.Range(0, 360), Random.Range(-15, 15));
        }
        BuildPlayer(); BuildDog();
    }

    void BuildPlayer()
    {
        pl = new GameObject("Player").transform;
        plVis = new GameObject("Vis").transform; plVis.SetParent(pl, false);
        Color skin = new Color(.9f, .72f, .58f), shirt = new Color(.33f, .36f, .44f), jeans = new Color(.2f, .3f, .5f), pack = new Color(.2f, .2f, .17f);
        Prim(PrimitiveType.Cube, plVis, new Vector3(0, 1.25f, 0), new Vector3(.5f, .6f, .28f), shirt);
        Prim(PrimitiveType.Sphere, plVis, new Vector3(0, 1.78f, 0), new Vector3(.28f, .3f, .28f), skin);
        Prim(PrimitiveType.Sphere, plVis, new Vector3(0, 1.9f, -.03f), new Vector3(.3f, .2f, .3f), new Color(.1f, .08f, .07f));
        Prim(PrimitiveType.Cube, plVis, new Vector3(0, 1.3f, -.25f), new Vector3(.4f, .5f, .22f), pack);
        plLegL = Pivot(plVis, new Vector3(-.13f, .9f, 0)); Prim(PrimitiveType.Cube, plLegL, new Vector3(0, -.45f, 0), new Vector3(.2f, .9f, .22f), jeans);
        plLegR = Pivot(plVis, new Vector3(.13f, .9f, 0)); Prim(PrimitiveType.Cube, plLegR, new Vector3(0, -.45f, 0), new Vector3(.2f, .9f, .22f), jeans);
        plArmL = Pivot(plVis, new Vector3(-.33f, 1.5f, 0)); Prim(PrimitiveType.Cube, plArmL, new Vector3(0, -.3f, 0), new Vector3(.14f, .6f, .16f), shirt);
        plArmR = Pivot(plVis, new Vector3(.33f, 1.5f, 0)); Prim(PrimitiveType.Cube, plArmR, new Vector3(0, -.3f, 0), new Vector3(.14f, .6f, .16f), shirt);
    }

    void BuildDog()
    {
        dog = new GameObject("Dog").transform;
        Color gold = new Color(.82f, .58f, .28f), dark = new Color(.55f, .36f, .16f);
        Prim(PrimitiveType.Cube, dog, new Vector3(0, .65f, 0), new Vector3(.4f, .4f, .9f), gold);
        dHead = Pivot(dog, new Vector3(0, .9f, .55f));
        Prim(PrimitiveType.Cube, dHead, new Vector3(0, .05f, .12f), new Vector3(.3f, .3f, .32f), gold);
        Prim(PrimitiveType.Cube, dHead, new Vector3(0, -.02f, .35f), new Vector3(.16f, .14f, .2f), dark);
        dEarL = Pivot(dHead, new Vector3(-.13f, .2f, .05f)); Prim(PrimitiveType.Cube, dEarL, new Vector3(0, -.05f, 0), new Vector3(.07f, .2f, .14f), dark);
        dEarR = Pivot(dHead, new Vector3(.13f, .2f, .05f)); Prim(PrimitiveType.Cube, dEarR, new Vector3(0, -.05f, 0), new Vector3(.07f, .2f, .14f), dark);
        dTail = Pivot(dog, new Vector3(0, .8f, -.45f)); Prim(PrimitiveType.Cube, dTail, new Vector3(0, .15f, 0), new Vector3(.08f, .35f, .08f), gold);
        float[] lx = { -.15f, .15f, -.15f, .15f }, lz = { .32f, .32f, -.32f, -.32f };
        for (int i = 0; i < 4; i++)
        {
            dLegs[i] = Pivot(dog, new Vector3(lx[i], .45f, lz[i]));
            Prim(PrimitiveType.Cube, dLegs[i], new Vector3(0, -.22f, 0), new Vector3(.1f, .45f, .1f), gold);
        }
    }

    void BuildAudio()
    {
        musicSrc = gameObject.AddComponent<AudioSource>();
        musicSrc.clip = MakePad(); musicSrc.loop = true; musicSrc.volume = volMusic; musicSrc.Play();
        sfxSrc = gameObject.AddComponent<AudioSource>(); woof = MakeWoof();
    }

    AudioClip MakePad()
    {
        int sr = 22050, n = sr * 6; var d = new float[n];
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / sr;
            float v = Mathf.Sin(2 * Mathf.PI * 220 * t) + .7f * Mathf.Sin(2 * Mathf.PI * 275 * t) + .6f * Mathf.Sin(2 * Mathf.PI * 330 * t);
            d[i] = v * .06f * (.75f + .25f * Mathf.Sin(2 * Mathf.PI * t / 3f));
        }
        var c = AudioClip.Create("pad", n, 1, sr, false); c.SetData(d, 0); return c;
    }

    AudioClip MakeWoof()
    {
        int sr = 22050, n = (int)(sr * .28f); var d = new float[n]; float ph = 0;
        for (int i = 0; i < n; i++)
        {
            float t = (float)i / n; ph += 2 * Mathf.PI * Mathf.Lerp(480, 170, t) / sr;
            d[i] = (Mathf.Sin(ph) * .6f + (Random.value - .5f) * .5f) * Mathf.Pow(1 - t, 2) * .5f;
        }
        var c = AudioClip.Create("woof", n, 1, sr, false); c.SetData(d, 0); return c;
    }

    void ApplyGfx()
    {
        float[] sc = { .6f, .8f, 1f };
        Screen.SetResolution((int)(nativeW * sc[resI]), (int)(nativeH * sc[resI]), true);
        sun.shadows = shadows ? LightShadows.Hard : LightShadows.None;
        QualitySettings.shadowDistance = gfx == 2 ? 40 : 20;
        QualitySettings.antiAliasing = aa ? 2 : 0;
        grassRoot.SetActive(gfx > 0);
        cam.farClipPlane = gfx == 0 ? 160 : 250;
    }

    void SaveGfx()
    {
        PlayerPrefs.SetInt("gfx", gfx); PlayerPrefs.SetInt("res", resI);
        PlayerPrefs.SetInt("sh", shadows ? 1 : 0); PlayerPrefs.SetInt("aa", aa ? 1 : 0);
    }

    // ---------------------------------------------------------------- game flow
    void ResetLevel()
    {
        bond = 0; stamina = 100; run = false; levelTime = 0; interactTimer = 0;
        gain = Mathf.Max(4, 14 - 2 * level); joyId = lookId = -1;
        pl.position = new Vector3(0, 0, -6); plYaw = 0; camYaw = 0; camPitch = 18;
        plVis.localScale = Vector3.one;
        dog.position = new Vector3(Mathf.Clamp(6 + level * 3, 6, 30), 0, 10);
        dYaw = 200; dSpeed = 0; dTarget = dog.position; dWait = 0;
        cam.transform.position = pl.position + new Vector3(0, 3, -6);
    }

    void StartGame() { ResetLevel(); page = Page.Play; }
    void EnterMenu() { page = Page.Menu; joyId = lookId = -1; }
    void Msg(string s) { msg = s; msgTimer = 1.6f; }

    void Complete()
    {
        stars = levelTime < 90 ? 3 : levelTime < 180 ? 2 : 1;
        level++; PlayerPrefs.SetInt("level", level); PlayerPrefs.Save();
        page = Page.Complete;
    }

    void DoInteract()
    {
        if (interactTimer > 0f || page != Page.Play) return;
        if (Vector3.Distance(pl.position, dog.position) > 3f) { Msg("Get closer to the dog"); return; }
        interactTimer = 2.2f; bond = Mathf.Min(100f, bond + gain);
        Msg("Good boy!  +" + (int)gain);
        sfxSrc.PlayOneShot(woof, volSfx);
    }

    void OnApplicationPause(bool p) { if (p && page == Page.Play) page = Page.Pause; }

    // ---------------------------------------------------------------- update
    void CalcScale()
    {
        S = Screen.height / 720f; vh = 720f; vw = Screen.width / S;
        rInteract = new Rect(vw - 140, vh - 210, 110, 110);
        rRun = new Rect(vw - 120, vh - 330, 84, 84);
        rPause = new Rect(vw - 80, 16, 60, 60);
    }

    void Update()
    {
        CalcScale();
        float dt = Mathf.Min(Time.deltaTime, .05f);
        if (msgTimer > 0) msgTimer -= dt;
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (page == Page.Play) page = Page.Pause;
            else if (page == Page.Pause) page = Page.Play;
            else if (page == Page.Settings || page == Page.Sound) page = back;
        }
        if (page == Page.Menu) MenuUpdate(dt);
        else if (page == Page.Play) PlayUpdate(dt);
    }

    void MenuUpdate(float dt)
    {
        menuT += dt;
        pl.position = Vector3.zero; plYaw = 90; PlayerPose(0, dt, true);
        dog.position = new Vector3(1.3f, 0, .1f); dYaw = -90; dSpeed = 0; dog.rotation = Quaternion.Euler(0, dYaw, 0);
        AnimateDog(dt, 1f, 1.3f);
        Vector3 c = new Vector3(.65f, .85f, 0);
        cam.transform.position = c + Quaternion.Euler(0, Mathf.Sin(menuT * .25f) * 20f, 0) * new Vector3(0, .6f, -3.6f);
        cam.transform.LookAt(c);
    }

    void PlayUpdate(float dt)
    {
        levelTime += dt;
        Vector2 mv, look; ReadInput(out mv, out look);
        camYaw += look.x * .12f; camPitch = Mathf.Clamp(camPitch - look.y * .12f, 5f, 60f);
        float spd = 0f; bool petting = interactTimer > 0f;
        if (petting)
        {
            interactTimer -= dt; mv = Vector2.zero;
            Vector3 to = dog.position - pl.position;
            plYaw = Mathf.LerpAngle(plYaw, Mathf.Atan2(to.x, to.z) * Mathf.Rad2Deg, 8 * dt);
        }
        bool running = false;
        if (mv.sqrMagnitude > .01f)
        {
            running = run && stamina > 2f;
            spd = (running ? 4.6f : 2.3f) * Mathf.Min(1f, mv.magnitude);
            Vector3 f = Quaternion.Euler(0, camYaw, 0) * new Vector3(mv.x, 0, mv.y); f.Normalize();
            plYaw = Mathf.LerpAngle(plYaw, Mathf.Atan2(f.x, f.z) * Mathf.Rad2Deg, 12 * dt);
            pl.position = Resolve(pl.position + f * spd * dt, .4f);
        }
        if (running) stamina -= 20 * dt; else stamina = Mathf.Min(100, stamina + 12 * dt);
        if (stamina <= 2f) run = false;
        plSpeed = spd;
        PlayerPose(spd, dt, petting);
        DogUpdate(dt, petting);
        CameraFollow(dt);
        if (bond >= 100f && !petting) Complete();
    }

    Vector3 Resolve(Vector3 p, float r)
    {
        foreach (var o in obs)
        {
            Vector2 d = new Vector2(p.x - o.x, p.z - o.y); float m = d.magnitude, min = o.z + r;
            if (m < min && m > .001f) { d = d / m * min; p.x = o.x + d.x; p.z = o.y + d.y; }
        }
        p.x = Mathf.Clamp(p.x, -46, 46); p.z = Mathf.Clamp(p.z, -46, 46);
        return p;
    }

    void PlayerPose(float spd, float dt, bool crouch)
    {
        anim += spd * dt * 3f; float k = Mathf.Clamp01(spd / 2.3f), s = Mathf.Sin(anim) * 35f * k;
        plLegL.localRotation = Quaternion.Euler(s, 0, 0); plLegR.localRotation = Quaternion.Euler(-s, 0, 0);
        plArmL.localRotation = Quaternion.Euler(crouch ? -60f : -s, 0, 0);
        plArmR.localRotation = Quaternion.Euler(crouch ? -70f : s, 0, 0);
        plVis.localScale = Vector3.Lerp(plVis.localScale, new Vector3(1, crouch ? .72f : 1f, 1), 10 * dt);
        pl.rotation = Quaternion.Euler(0, plYaw, 0);
    }

    void CameraFollow(float dt)
    {
        Vector3 t = pl.position + Vector3.up * 1.5f;
        Vector3 want = t - Quaternion.Euler(camPitch, camYaw, 0) * Vector3.forward * 5.2f;
        want.y = Mathf.Max(want.y, .5f);
        cam.transform.position = Vector3.Lerp(cam.transform.position, want, 1 - Mathf.Exp(-14 * dt));
        cam.transform.LookAt(t);
    }

    // ---------------------------------------------------------------- dog AI
    void DogUpdate(float dt, bool petting)
    {
        Vector3 dp = dog.position, to = pl.position - dp; to.y = 0; float d = to.magnitude;
        Vector3 dir = to; float want = 0f, happy = .4f;
        if (petting) happy = 1f;
        else if (plSpeed > 3.5f && d < 5f && d > 1.2f) { dir = -to; want = 2.6f; happy = .1f; } // দৌড়ালে ভয় পেয়ে সরে যায়
        else if (d < 2.2f) happy = .8f;
        else if (d < 16f) { want = d > 8f ? 3.8f : 1.8f; happy = .7f; }                          // কাছে এলে অনুসরণ করে
        else
        {
            dWait -= dt;
            if (dWait <= 0f || (dTarget - dp).sqrMagnitude < 1f)
            { dTarget = new Vector3(Random.Range(-35f, 35f), 0, Random.Range(-35f, 35f)); dWait = Random.Range(4f, 9f); }
            dir = dTarget - dp; dir.y = 0; want = 1.2f;                                            // দূরে থাকলে ঘুরে বেড়ায়
        }
        if (dir.sqrMagnitude > .01f)
        {
            float ty = Mathf.Atan2(dir.x, dir.z) * Mathf.Rad2Deg;
            dYaw = Mathf.MoveTowardsAngle(dYaw, ty, 200 * dt);
            if (Mathf.Abs(Mathf.DeltaAngle(dYaw, ty)) > 50f) want *= .2f;
        }
        dSpeed = Mathf.Lerp(dSpeed, want, 6 * dt);
        Vector3 np = Resolve(dp + Quaternion.Euler(0, dYaw, 0) * Vector3.forward * dSpeed * dt, .35f);
        Vector3 sep = np - pl.position; sep.y = 0;
        if (sep.magnitude < .9f && sep.sqrMagnitude > 1e-4f) np = pl.position + sep.normalized * .9f;
        dog.position = np; dog.rotation = Quaternion.Euler(0, dYaw, 0);
        AnimateDog(dt, happy, d);
    }

    void AnimateDog(float dt, float happy, float d)
    {
        float k = Mathf.Clamp01(dSpeed / 2f); dPhase += dSpeed * dt * 4.5f;
        for (int i = 0; i < 4; i++)
        {
            float off = (i == 0 || i == 3) ? 0f : Mathf.PI;
            dLegs[i].localRotation = Quaternion.Euler(Mathf.Sin(dPhase + off) * 32f * k, 0, 0);
        }
        float wag = Mathf.Sin(Time.time * (6 + 9 * happy)) * (20 + 25 * happy) * happy;
        dTail.localRotation = Quaternion.Euler(Mathf.Lerp(-150f, -40f, happy), wag, 0);
        Vector3 lp = dog.InverseTransformDirection(pl.position - dog.position);
        float ang = Mathf.Clamp(Mathf.Atan2(lp.x, lp.z) * Mathf.Rad2Deg, -50f, 50f);
        dHead.localRotation = Quaternion.Lerp(dHead.localRotation, Quaternion.Euler(0, d < 9f ? ang : 0f, 0), 6 * dt);
        float ear = 10f + (1f - happy) * 40f;
        dEarL.localRotation = Quaternion.Euler(0, 0, ear); dEarR.localRotation = Quaternion.Euler(0, 0, -ear);
    }

    // ---------------------------------------------------------------- input
    void ReadInput(out Vector2 mv, out Vector2 look)
    {
        look = Vector2.zero;
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch t = Input.GetTouch(i);
            Vector2 v = new Vector2(t.position.x / S, (Screen.height - t.position.y) / S);
            bool end = t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled;
            if (t.phase == TouchPhase.Began && !rInteract.Contains(v) && !rRun.Contains(v) && !rPause.Contains(v))
            {
                if (v.x < vw * .45f) { if (joyId < 0) { joyId = t.fingerId; joyStart = v; joyVec = Vector2.zero; } }
                else if (lookId < 0) lookId = t.fingerId;
            }
            if (t.fingerId == joyId) { if (end) joyId = -1; else joyVec = Vector2.ClampMagnitude((v - joyStart) / 70f, 1f); }
            else if (t.fingerId == lookId) { if (end) lookId = -1; else look += t.deltaPosition / S; }
        }
        mv = joyId >= 0 ? new Vector2(joyVec.x, -joyVec.y) : Vector2.zero;
        mv += new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        mv = Vector2.ClampMagnitude(mv, 1f);
        if (Input.GetMouseButton(1)) look += new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 8f;
        if (Input.GetKeyDown(KeyCode.E)) DoInteract();
    }

    // ---------------------------------------------------------------- UI (IMGUI)
    void InitStyles()
    {
        label = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = 28 };
        label.normal.textColor = Color.white;
        btn = new GUIStyle { alignment = TextAnchor.MiddleCenter, fontSize = 26, fontStyle = FontStyle.Bold };
        btn.normal.textColor = Color.white;
        int n = 64; circ = new Texture2D(n, n, TextureFormat.RGBA32, false); var px = new Color32[n * n];
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            {
                float dx = x - n / 2f + .5f, dy = y - n / 2f + .5f;
                px[y * n + x] = new Color32(255, 255, 255, (byte)(Mathf.Clamp01(n / 2f - Mathf.Sqrt(dx * dx + dy * dy)) * 255));
            }
        circ.SetPixels32(px); circ.Apply(); circ.filterMode = FilterMode.Bilinear;
    }

    static readonly Color GREEN = new Color(.2f, .62f, .25f), DARK = new Color(.1f, .14f, .2f, .92f), GRAY = new Color(.3f, .34f, .4f, .95f);

    void Box(Rect r, Color c) { var o = GUI.color; GUI.color = c; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = o; }
    void Circ(Rect r, Color c) { var o = GUI.color; GUI.color = c; GUI.DrawTexture(r, circ); GUI.color = o; }
    bool Btn(Rect r, string t, Color c) { Box(r, c); return GUI.Button(r, t, btn); }
    void Txt(Rect r, string t, int size = 28, TextAnchor a = TextAnchor.MiddleCenter) { label.fontSize = size; label.alignment = a; GUI.Label(r, t, label); }
    void Bar(Rect r, float f, Color c) { Box(r, new Color(0, 0, 0, .5f)); Box(new Rect(r.x, r.y, r.width * Mathf.Clamp01(f), r.height), c); }
    int Seg(float x, float y, string[] names, int sel)
    {
        for (int i = 0; i < names.Length; i++)
            if (Btn(new Rect(x + i * 170, y, 160, 54), names[i], i == sel ? GREEN : GRAY)) return i;
        return -1;
    }

    void OnGUI()
    {
        if (label == null) InitStyles();
        CalcScale();
        GUI.matrix = Matrix4x4.Scale(new Vector3(S, S, 1));
        switch (page)
        {
            case Page.Menu: DrawMenu(); break;
            case Page.Play: DrawHud(); break;
            case Page.Pause: DrawHud(); DrawPause(); break;
            case Page.Settings: DrawSettings(); break;
            case Page.Sound: DrawSound(); break;
            case Page.Complete: DrawComplete(); break;
        }
    }

    void DrawMenu()
    {
        Box(new Rect(0, 0, 520, vh), new Color(0, 0, 0, .3f));
        Txt(new Rect(40, 30, 480, 100), "Animal Friend", 64, TextAnchor.MiddleLeft);
        Txt(new Rect(44, 120, 480, 40), "A Small Kindness, A Big Bond", 24, TextAnchor.MiddleLeft);
        if (Btn(new Rect(50, 240, 360, 64), "PLAY  (Level " + level + ")", GREEN)) StartGame();
        if (Btn(new Rect(50, 320, 360, 56), "SETTINGS", DARK)) { back = Page.Menu; page = Page.Settings; }
        if (Btn(new Rect(50, 390, 360, 56), "SOUND", DARK)) { back = Page.Menu; page = Page.Sound; }
        if (Btn(new Rect(50, 460, 360, 56), "QUIT", DARK)) Application.Quit();
    }

    void DrawHud()
    {
        Box(new Rect(18, 18, 330, 56), new Color(0, 0, 0, .4f));
        Txt(new Rect(22, 22, 50, 22), "Bond", 15, TextAnchor.MiddleLeft);
        Txt(new Rect(22, 48, 50, 22), "Run", 15, TextAnchor.MiddleLeft);
        Bar(new Rect(76, 27, 180, 14), bond / 100f, new Color(.95f, .35f, .2f));
        Bar(new Rect(76, 52, 180, 14), stamina / 100f, new Color(.25f, .85f, .35f));
        Txt(new Rect(262, 22, 84, 30), "Lv " + level, 22);
        if (msgTimer > 0) Txt(new Rect(vw / 2 - 250, 90, 500, 40), msg, 26);

        Vector2 bc = joyId >= 0 ? joyStart : new Vector2(150, vh - 150);
        Circ(new Rect(bc.x - 70, bc.y - 70, 140, 140), new Color(1, 1, 1, .18f));
        Vector2 kn = bc + (joyId >= 0 ? joyVec * 70f : Vector2.zero);
        Circ(new Rect(kn.x - 30, kn.y - 30, 60, 60), new Color(1, 1, 1, .45f));

        bool near = page == Page.Play && Vector3.Distance(pl.position, dog.position) < 3f;
        Circ(rInteract, near ? new Color(.2f, .75f, .3f, .85f) : new Color(1, 1, 1, .3f));
        Txt(rInteract, "PET", 26);
        if (near && interactTimer <= 0f) { Box(new Rect(rInteract.x - 120, rInteract.y + 38, 110, 34), new Color(0, 0, 0, .6f)); Txt(new Rect(rInteract.x - 120, rInteract.y + 38, 110, 34), "Interact", 20); }
        Circ(rRun, run ? new Color(.2f, .75f, .3f, .85f) : new Color(1, 1, 1, .3f));
        Txt(rRun, "RUN", 22);
        Circ(rPause, new Color(0, 0, 0, .5f)); Txt(rPause, "II", 26);
        if (page != Page.Play) return;
        if (GUI.Button(rInteract, GUIContent.none, btn)) DoInteract();
        if (GUI.Button(rRun, GUIContent.none, btn)) run = !run;
        if (GUI.Button(rPause, GUIContent.none, btn)) page = Page.Pause;
    }

    void DrawPause()
    {
        Box(new Rect(0, 0, vw, vh), new Color(0, 0, 0, .55f));
        float x = vw / 2 - 190, y = vh / 2 - 220;
        Box(new Rect(x, y, 380, 440), DARK);
        Txt(new Rect(x, y + 10, 380, 70), "PAUSED", 44);
        if (Btn(new Rect(x + 40, y + 100, 300, 60), "RESUME", GREEN)) page = Page.Play;
        if (Btn(new Rect(x + 40, y + 175, 300, 60), "RESTART", GRAY)) StartGame();
        if (Btn(new Rect(x + 40, y + 250, 300, 60), "SETTINGS", GRAY)) { back = Page.Pause; page = Page.Settings; }
        if (Btn(new Rect(x + 40, y + 325, 300, 60), "EXIT", GRAY)) EnterMenu();
    }

    void DrawSettings()
    {
        Box(new Rect(0, 0, vw, vh), new Color(.05f, .08f, .12f, .97f));
        if (Btn(new Rect(24, 24, 70, 56), "<", GRAY)) page = back;
        Txt(new Rect(110, 24, 300, 56), "SETTINGS", 32, TextAnchor.MiddleLeft);
        Btn(new Rect(24, 110, 240, 60), "Graphics", GREEN);
        if (Btn(new Rect(24, 180, 240, 60), "Sound", DARK)) page = Page.Sound;

        float x = 320;
        Txt(new Rect(x, 100, 400, 36), "Graphics Quality", 24, TextAnchor.MiddleLeft);
        int q = Seg(x, 140, new[] { "Low", "Medium", "High" }, gfx);
        if (q >= 0) { gfx = q; resI = q; shadows = q > 0; aa = q == 2; ApplyGfx(); SaveGfx(); }
        if (gfx == 0) Txt(new Rect(x, 198, 500, 30), "Recommended for 2GB RAM devices", 18, TextAnchor.MiddleLeft);
        Txt(new Rect(x, 250, 400, 36), "Resolution", 24, TextAnchor.MiddleLeft);
        int r = Seg(x, 290, new[] { "Low", "Medium", "High" }, resI);
        if (r >= 0) { resI = r; ApplyGfx(); SaveGfx(); }
        Txt(new Rect(x, 370, 300, 40), "Shadows", 24, TextAnchor.MiddleLeft);
        if (Btn(new Rect(x + 300, 370, 120, 46), shadows ? "ON" : "OFF", shadows ? GREEN : GRAY)) { shadows = !shadows; ApplyGfx(); SaveGfx(); }
        Txt(new Rect(x, 435, 300, 40), "Anti-Aliasing", 24, TextAnchor.MiddleLeft);
        if (Btn(new Rect(x + 300, 435, 120, 46), aa ? "ON" : "OFF", aa ? GREEN : GRAY)) { aa = !aa; ApplyGfx(); SaveGfx(); }
    }

    void DrawSound()
    {
        Box(new Rect(0, 0, vw, vh), new Color(.05f, .08f, .12f, .97f));
        if (Btn(new Rect(24, 24, 70, 56), "<", GRAY)) page = back;
        Txt(new Rect(110, 24, 400, 56), "SOUND SETTINGS", 32, TextAnchor.MiddleLeft);
        Txt(new Rect(120, 160, 160, 40), "Music", 26, TextAnchor.MiddleLeft);
        float m = GUI.HorizontalSlider(new Rect(300, 168, 600, 40), volMusic, 0f, 1f);
        if (!Mathf.Approximately(m, volMusic)) { volMusic = m; musicSrc.volume = m; PlayerPrefs.SetFloat("mus", m); }
        Txt(new Rect(930, 160, 100, 40), Mathf.RoundToInt(volMusic * 100) + "%", 24);
        Txt(new Rect(120, 250, 160, 40), "SFX", 26, TextAnchor.MiddleLeft);
        float s = GUI.HorizontalSlider(new Rect(300, 258, 600, 40), volSfx, 0f, 1f);
        if (!Mathf.Approximately(s, volSfx)) { volSfx = s; PlayerPrefs.SetFloat("sfx", s); }
        Txt(new Rect(930, 250, 100, 40), Mathf.RoundToInt(volSfx * 100) + "%", 24);
    }

    void DrawComplete()
    {
        Box(new Rect(0, 0, vw, vh), new Color(0, 0, 0, .6f));
        float x = vw / 2 - 220, y = vh / 2 - 190;
        Box(new Rect(x, y, 440, 380), DARK);
        Txt(new Rect(x, y + 10, 440, 60), "Level Complete", 38);
        for (int i = 0; i < 3; i++)
            Circ(new Rect(x + 110 + i * 80, y + 85, 60, 60), i < stars ? new Color(1f, .8f, .1f) : new Color(.35f, .35f, .35f));
        Txt(new Rect(x, y + 165, 440, 40), "Well Done!", 26);
        if (Btn(new Rect(x + 40, y + 230, 360, 60), "NEXT LEVEL", GREEN)) StartGame();
        if (Btn(new Rect(x + 40, y + 305, 360, 56), "MAIN MENU", GRAY)) EnterMenu();
    }
}
