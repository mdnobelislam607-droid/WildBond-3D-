# Animal Friend (Android, অফলাইন 3D)

Android অ্যাপ (Gradle) + ভেতরে Three.js গেম। কোনো INTERNET permission নেই, তাই অ্যাপ পুরোপুরি অফলাইন।
Three.js GitHub Actions বিল্ডের সময় নামিয়ে APK-এর ভেতরে ঢোকানো হয়।

কন্ট্রোল: বামে ড্র্যাগ = হাঁটা, ডানে সোয়াইপ = ক্যামেরা, PET = কুকুরকে আদর, RUN = দৌড়।
PC টেস্ট: WASD, E, Shift, Esc।
